Chef::Log.warn('The purge_packages recipe has been deprecated and will be removed from the next major release of the Java cookbook')
